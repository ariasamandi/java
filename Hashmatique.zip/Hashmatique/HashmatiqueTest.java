public class HashmatiqueTest{
    public static void main(String[] args){
        Hashmatique hash = new Hashmatique();
        System.out.println(hash.tracklist());
    }
}