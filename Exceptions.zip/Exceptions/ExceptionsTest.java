public class ExceptionsTest{
    public static void main(String[] args){
        Exceptions a = new Exceptions();
        System.out.println(a.ex());
    }
}