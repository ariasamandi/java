public class PythagoreanTheoremTest{
    public static void main(String[] args){
        PythagoreanTheorem iD = new PythagoreanTheorem();
        System.out.println(iD.calculateHypotenuse(2,3));
    }
}